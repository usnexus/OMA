#!/bin/sh

echo friendly neighbour spiderman