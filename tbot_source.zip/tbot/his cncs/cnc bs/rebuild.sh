go mod tidy; go build; pkill -f cnc; ulimit -n 999999; screen -S cnc ./cnc
