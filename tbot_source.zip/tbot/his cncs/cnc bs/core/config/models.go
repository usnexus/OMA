package config

var Config *ConfigModel

type ConfigModel struct {
	Server struct {
		Host string `json:"host"`
		Port int    `json:"port"`
	} `json:"server"`
	Database struct {
		Path string `json:"path"`
	} `json:"database"`
	Logs struct {
		BotToken string `json:"botToken"`
		ChatId   int    `json:"ChatId"`
	} `json:"logs"`
}
